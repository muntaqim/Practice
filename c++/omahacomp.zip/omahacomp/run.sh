make clean
make
./omahacomp.exe input.txt output.txt
